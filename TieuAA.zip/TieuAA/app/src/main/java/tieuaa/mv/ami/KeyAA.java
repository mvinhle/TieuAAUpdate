package tieuaa.mv.ami;

public class KeyAA {
    public static String NAME_INFORMATION = "INFORMATION";
    public static String NAME_TRUST = "TRUST";

    public static String KEY_NAME_INFORMATION = "NAME_OF_USER";
    public static String KEY_SEX_INFORMATION  = "SEX_OF_USER";
    public static String KEY_POINT_TRUST      = "POINT_TRUST";
    public static String KEY_SUBJECT_LEARNING = "SUBJECT_LEARNING";

    public static String KEY_LOG = "LeMinhVinh";

    public static String KEY_FIX_BUG_INFORMARTION = " sanPhamDuocPhatTrienBoiLeMinhVinh15092018 ";

    public static String ALIAS_GIRL = "chị";
    public static String ALIAS_BOY  = "anh";
    public static String ALIAS_AA   = "em";
    public static String NAME_AA    = "Ami";

    public static long POINT_TRUST_DEFAULT = 150;
    public static String KEY_NAME_USER  = "[nyou]";
    public static String KEY_ALIAS_USER = "[you]";
    public static String KEY_NAME_AA    = "[ni]";
    public static String KEY_ALIAS_AA   = "[i]";
}
